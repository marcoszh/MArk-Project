import os
import sys
import json
# import boto3
# import tarfile
"""
This is needed so that the script running on AWS will pick up the pre-compiled dependencies
from the vendored folder
"""
HERE = os.path.dirname(os.path.realpath(__file__))
sys.path.append(os.path.join(HERE, "vendored"))
# from six.moves import urllib

# s3 = boto3.resource('s3')
"""
Now that the script knows where to look, we can safely import our objects
"""
# print "loading libs!"
# LIB_NAME='big2.tar.gz'
# LIB_DEF_PATH = os.path.join(os.sep, 'tmp', 'big2.tar.gz')

# print('Downloading Model from S3...')
# s3.Bucket('dl-model-bucket-zcl').download_file(LIB_NAME, LIB_DEF_PATH)

# tar = tarfile.open(LIB_DEF_PATH)
# tar.extractall(path='/tmp/')
# tar.close()
# sys.path.append('/tmp/big2')

import tensorflow as tf
# from tf.keras.applications.MobileNet import MobileNet
# from tf.keras.preprocessing import image
# from tf.keras.applications.MobileNet import preprocess_input, decode_predictions
import numpy as np
"""
Declare here global objects living across requests
"""

print "preprocess pic"
img_path = 'cat.jpg'
img = tf.keras.preprocessing.image.load_img(img_path, target_size=(224, 224))
#img = np.zeros(3,224, 224)
x = tf.keras.preprocessing.image.img_to_array(img)
x = np.expand_dims(x, axis=0)
x = tf.keras.applications.inception_v3.preprocess_input(x)

# just print a message so we can verify in AWS the loading of dependencies was correct
print "loaded done!"
model = tf.keras.applications.InceptionV3(weights='imagenet')

print "loaded model!"

# def get_param_from_url(event, param_name):
#     """
#     Helper function to retrieve query parameters from a Lambda call. Parameters are passed through the
#     event object as a dictionary.

#     :param event: the event as input in the Lambda function
#     :param param_name: the name of the parameter in the query string
#     :return: the parameter value
#     """
#     params = event['queryStringParameters']
#     return params[param_name]


def return_lambda_gateway_response(code, body):
    """
    This function wraps around the endpoint responses in a uniform and Lambda-friendly way

    :param code: HTTP response code (200 for OK), must be an int
    :param body: the actual content of the response
    """
    return {"statusCode": code, "body": str(body)}


def predict(event, context):
    """
    This is the function called by AWS Lambda, passing the standard parameters "event" and "context"
    When deployed, you can try it out pointing your browser to

    {LambdaURL}/{stage}/predict?x=2.7

    where {LambdaURL} is Lambda URL as returned by serveless installation and {stage} is set in the
    serverless.yml file.

    """
    try:
        
        print "start predicting!"

        preds = model.predict(x)
        value = tf.keras.applications.inception_v3.decode_predictions(preds, top=1)[0]
        print(value)
    except Exception as ex:
        error_response = {
            'error_message': "Unexpected error",
            'stack_trace': str(ex)
        }
        return return_lambda_gateway_response(503, error_response)

    return return_lambda_gateway_response(200, {'value': value})



