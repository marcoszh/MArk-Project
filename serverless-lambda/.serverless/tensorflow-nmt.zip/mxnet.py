import os
import sys
import json
import time
# import boto3
# import tarfile
"""
This is needed so that the script running on AWS will pick up the pre-compiled dependencies
from the vendored folder
"""
HERE = os.path.dirname(os.path.realpath(__file__))
sys.path.append(os.path.join(HERE, "vendored"))
# from six.moves import urllib

# s3 = boto3.resource('s3')
"""
Now that the script knows where to look, we can safely import our objects
"""
# print "loading libs!"
# LIB_NAME='big2.tar.gz'
# LIB_DEF_PATH = os.path.join(os.sep, 'tmp', 'big2.tar.gz')

# print('Downloading Model from S3...')
# s3.Bucket('dl-model-bucket-zcl').download_file(LIB_NAME, LIB_DEF_PATH)

# tar = tarfile.open(LIB_DEF_PATH)
# tar.extractall(path='/tmp/')
# tar.close()
# sys.path.append('/tmp/big2')
# from tf.keras.applications.MobileNet import MobileNet
# from tf.keras.preprocessing import image
# from tf.keras.applications.MobileNet import preprocess_input, decode_predictions
import numpy as np
"""
Declare here global objects living across requests
"""


# just print a message so we can verify in AWS the loading of dependencies was correct

print "loaded model!"

# def get_param_from_url(event, param_name):
#     """
#     Helper function to retrieve query parameters from a Lambda call. Parameters are passed through the
#     event object as a dictionary.

#     :param event: the event as input in the Lambda function
#     :param param_name: the name of the parameter in the query string
#     :return: the parameter value
#     """
#     params = event['queryStringParameters']
#     return params[param_name]


def return_lambda_gateway_response(code, body):
    """
    This function wraps around the endpoint responses in a uniform and Lambda-friendly way

    :param code: HTTP response code (200 for OK), must be an int
    :param body: the actual content of the response
    """
    return {"statusCode": code, "body": str(body)}


def predict(event, context):
    """
    This is the function called by AWS Lambda, passing the standard parameters "event" and "context"
    When deployed, you can try it out pointing your browser to

    {LambdaURL}/{stage}/predict?x=2.7

    where {LambdaURL} is Lambda URL as returned by serveless installation and {stage} is set in the
    serverless.yml file.

    """
    try:
        
        print "start predicting!"

        time.sleep(0.06)
        value = "the <unk> 's the the as the 's the the 're to a <unk> <unk> <unk> analyst company trading at "
        print(value)
    except Exception as ex:
        error_response = {
            'error_message': "Unexpected error",
            'stack_trace': str(ex)
        }
        return return_lambda_gateway_response(503, error_response)

    return return_lambda_gateway_response(200, {'value': value})



