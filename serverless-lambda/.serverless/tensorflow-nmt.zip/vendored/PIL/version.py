# Master version for Pillow
__version__ = '5.1.0'
